﻿using System;

namespace LoginValidation
{
    public class Class1
    {
    }
}
