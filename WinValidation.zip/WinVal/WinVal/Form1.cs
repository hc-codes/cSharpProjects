﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinVal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {            
            string str = Validate(sender, 3, 6);
            if (str != null)
            {
                lblName.Text = str;
            }
            else
            {
                lblName.Text = "";
            }
        }

        private string Validate(object sender, int minLength, int maxLength)
        {
            TextBox txt = (TextBox)sender;            
            string val = txt.Text;
            if (string.IsNullOrEmpty(val))
            {
                return "This Field is Mandatory";
            }
            if(val.Length<minLength || val.Length > maxLength)
            {
                return $"Must be between {minLength} and {maxLength} characters";
            }
            return null;
        }

        private void txtPass_TextChanged(object sender, EventArgs e)
        {
            string str = Validate(sender, 3, 6);
            if (str != null)
            {
                lblPass.Text = str;
            }
            else
            {
                lblPass.Text = "";
            }
        }
    }
}
