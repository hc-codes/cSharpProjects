﻿using Shop.Library.Models;
using Shop.Library.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinPOS
{
    public partial class Form1 : Form
    {
        IProductRepository productRepository = new FileProductRepository();
        Cart myCart;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            TextBox txt = (TextBox)sender;
            string text = txt.Text;
            if (text.Length < 2)
            {
                return;
            }
            List<Product> products = productRepository.Search(text);
            UpdateResults(products);
        }

        private void UpdateResults(List<Product> products)
        {
            lbResults.Items.Clear();
            foreach (var item in products)
            {
                lbResults.Items.Add(item);
            }
        }

        private void lbResults_SelectedIndexChanged(object sender, EventArgs e)
        {
            Product selected = lbResults.SelectedItem as Product;
            if (selected == null)
            {
                return;
            }
            if (myCart == null)
            {
                myCart = new Cart();
            }
            myCart.Add(selected);
            ShowCart();
        }

        private void ShowCart()
        {
            lvCart.Items.Clear();
            int it = 1;
            foreach (var item in myCart.Contents)
            {
                ListViewItem itm = lvCart.Items.Add(it.ToString());
                it++;
                itm.SubItems.Add(item.Key.Id.ToString());
                itm.SubItems.Add(item.Key.Name.ToString());
                itm.SubItems.Add(item.Key.Category.ToString());
                itm.SubItems.Add(item.Key.Price.ToString());
                itm.SubItems.Add(item.Value.ToString());
                itm.SubItems.Add((item.Key.Price * item.Value).ToString());
            }
            lblTotal.Text = myCart.ComputeTotal().ToString();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearCart();
        }

        private void ClearCart()
        {
            myCart = new Cart();
            ShowCart();
        }
        private void btnPrintBill_Click(object sender, EventArgs e)
        {
            ClearCart();
        }
    }
}
