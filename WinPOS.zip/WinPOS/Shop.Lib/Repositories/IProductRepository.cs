﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Shop.Library.Models;

namespace Shop.Library.Repositories
{
    public interface IProductRepository
    {
        List<string> GetCategories();
        void Create(Product product);
        IEnumerable<Product> Read();
        Product Read(int id);
        List<Product> Read(string category);
        int GetNextId();//this is an interface so no body
        List<Product> Search(string txt);
    }
}