﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtMeth
{
    public static class IntMethods
    {
        public static int Square(this int a)
        {
            return a * a;
        }
    }
}
