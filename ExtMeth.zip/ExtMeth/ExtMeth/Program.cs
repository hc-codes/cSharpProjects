﻿using System;


namespace ExtMeth
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 10;
            Console.WriteLine(x.Square());
        }
    }
}
