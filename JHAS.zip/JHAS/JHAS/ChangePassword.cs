﻿using System;
using System.Windows.Forms;

namespace JHAS
{
    public partial class ChangePassword : Form
    {
        public ChangePassword()
        {
            InitializeComponent();
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            //Form1 f = new Form1();
            //if (txtNewUsername.Text == txtNewPassword.Text)
            //    f.pass = txtNewUsername.Text;
            //this.Close();
            //f.Show();
        }
    }
}