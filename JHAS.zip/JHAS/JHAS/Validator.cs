﻿namespace JHAS
{
    public class Validator
    {
        public int MinLength { get; set; }
        public int MaxLength { get; set; }
        string numbers = "0123456789";
        public Validator()
        {
            MinLength = 2;
            MaxLength = 16;
        }
        public string ValidateName(string name)
        {
            if (string.IsNullOrEmpty(name))
                return " is required";
            else if (name.Length < MinLength || name.Length > MaxLength)
                return $" Must be between {MinLength} and {MaxLength}";
            else
                return null;
        }
        public string Validate(string arg)
        {
            if (string.IsNullOrEmpty(arg))
            {
                return " is required.";
            }
            else if (arg.Length < MinLength || arg.Length > MaxLength)
                return $" Must be between {MinLength} and {MaxLength}";
            else
                return null;
        }
    }
}