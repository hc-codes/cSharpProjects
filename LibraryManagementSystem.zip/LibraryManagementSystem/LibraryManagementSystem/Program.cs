﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            LoginPanel panel = new LoginPanel();
            panel.LoginMenu();
        }
    }
}
