﻿LIBRARY MANAGEMENT USING LISTS IN C#

<===================================================> CONTROL FLOW <==================================================================>

PROGRAM => LOGIN PANEL => RESPECTIVE DASHBOARD => RESPECTIVE OPERATIONS

<=====================================================================================================================================>


<=====================================================> OPERATIONS <==================================================================>

<==========> ADMIN OPERATIONS ====> MANAGE ALL USER OPERATIONS =====> MANAGE ALL BOOK OPERATIONS =====> UPDATE OWN DETAILS <==========>

<=======> LIBRARIAN OPERATIONS =====> MANAGE STUDENT OPERATIONS =====> MANAGE ALL BOOK OPERATIONS ======> UPDATE OWN DETAILS <========>

<=====================================================================================================================================>


** Book counts are not implemented even though it asks for book count.


** Initial login credentials =>username: admin, password: admin -> admin login
							 =>username: lib,   password: lib   -> librarian login
							 =>username: s1/s2/s3, password: s1/s2/s3 -> student login