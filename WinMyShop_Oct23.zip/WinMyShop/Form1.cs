﻿using Shop.Library.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinMyShop
{
    public partial class Form1 : Form
    {
        private IProductRepository productRepository = new FileProductRepository();
        public Form1()
        {
            InitializeComponent();
        }

        private void salesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SalesForm sales = new SalesForm(productRepository);
            sales.ShowDialog(this);
        }

        private void listingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProductListForm listForm = new ProductListForm(this.productRepository);
            listForm.ShowDialog(this);
        }

        private void addNewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProductForm productForm = new ProductForm(this.productRepository);
            productForm.ShowDialog(this);
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
