﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Library.Models;
using Shop.Library.Repositories;

namespace WinMyShop
{
    public partial class ProductListForm : Form
    {
        private IProductRepository productRepository;
        public ProductListForm(IProductRepository productRepository)
        {
            InitializeComponent();
            this.productRepository = productRepository;
        }

        private void ProductListForm_Load(object sender, EventArgs e)
        {
            List<string> categories = productRepository.GetCategories();
            cbCategories.DataSource = categories;
        }

        private void cbCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedCategory = (string)cbCategories.SelectedItem;
            List<Product> products = this.productRepository.Read(selectedCategory);
            UpdateListView(products);
        }

        private void UpdateListView(List<Product> products)
        {
            lvProducts.Items.Clear();
            lvProducts.View = View.Details;
            lvProducts.GridLines = true;
            lvProducts.FullRowSelect = true;

            foreach (var p in products)
            {
                ListViewItem item = new ListViewItem(p.Id.ToString());
                item.SubItems.Add(p.Category);
                item.SubItems.Add(p.Name);
                item.SubItems.Add(p.Price.ToString());
                item.SubItems.Add(p.Stock.ToString());
                lvProducts.Items.Add(item);
            }
        }
    }
}
