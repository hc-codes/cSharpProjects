﻿using Shop.Library.Models;
using Shop.Library.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Library.Models.Validators;

namespace WinMyShop
{
    public partial class ProductForm : Form
    {
        RequiredValidator rVal = new RequiredValidator();
        IntegerValidator iVal = new IntegerValidator();
        DoubleValidator dVal = new DoubleValidator();

        private IProductRepository productRepository;
        public ProductForm(IProductRepository productRepository)
        {
            InitializeComponent();
            this.productRepository = productRepository;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            
            //bool saved = false;
            try
            {
                Product p = MakeProduct();

                productRepository.Create(p);
                MessageBox.Show("Product saved");                           
                
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(btnSave, ex.Message);
            }
            /*if (saved)
            {
                ProductForm_Load(null, null);
                txtCategory.Clear();
                txtName.Clear();
                txtPrice.Clear();
                txtStock.Clear();
            }*/
        }

        private Product MakeProduct()
        {


            Product p = new Product();
            bool isValid = true;
            string idVal = iVal.Validate(txtId.Text);

            if (idVal != null)
            {
                errorProvider1.SetError(txtId, "Id" + idVal);
                isValid = false;
            }
            else
            {
                p.Id = Convert.ToInt32(txtId.Text);
                errorProvider1.SetError(txtId, null);
            }

            string catVal = rVal.Validate(txtCategory.Text);
            if (catVal != null)
            {
                errorProvider1.SetError(txtCategory, "Category" + catVal);
                isValid = false;
            }
            else
            {
                p.Category = txtCategory.Text;
                errorProvider1.SetError(txtCategory, null);
            }

            string nVal = rVal.Validate(txtName.Text);
            if (nVal != null)
            {
                errorProvider1.SetError(txtName, "Name" + nVal);
                isValid = false;
            }
            else
            {
                p.Name = txtName.Text;
                errorProvider1.SetError(txtName, null);
            }

            string pVal = dVal.Validate(txtPrice.Text);
            if (pVal != null)
            {
                errorProvider1.SetError(txtPrice, "Price" + pVal);
                isValid = false;
            }
            else
            {
                p.Price = Convert.ToDouble(txtPrice.Text);
                errorProvider1.SetError(txtPrice, null);
            }

            string sVal = iVal.Validate(txtStock.Text);
            if (sVal != null)
            {
                errorProvider1.SetError(txtStock, "Stock" + sVal);
                isValid = false;
            }
            else
            {
                p.Stock = Convert.ToInt32(txtStock.Text);
                errorProvider1.SetError(txtStock, null);
            }
            if (!isValid)
            {
                throw new Exception("Errors");
                //MessageBox.Show("Enter Mandatory Fields");
                //return null;
            }
            return p;
        }

        private void ProductForm_Load(object sender, EventArgs e)
        {
            txtId.Text = this.productRepository.GetNextId().ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtCategory_Validating(object sender, CancelEventArgs e)
        {
            TextBox txt = (TextBox)sender;
            string catVals = rVal.Validate(txt.Text);
            if (catVals != null)
            {
                
                txt.BackColor = Color.Yellow;
                e.Cancel = true;
            }
            else
            {
                txt.BackColor = SystemColors.Control;
            }
        }

        private void txtPrice_Validating(object sender, CancelEventArgs e)
        {
            TextBox txt = (TextBox)sender;
            string catVals = dVal.Validate(txt.Text);
            if (catVals != null)
            {
                txt.BackColor = Color.Yellow;
                txt.ForeColor = Color.Red;
                errorProvider1.SetError(txt, catVals);
                e.Cancel = true;
            }
            else
            {
                txt.BackColor = SystemColors.Control;
                txt.ForeColor = SystemColors.ControlText;
                errorProvider1.SetError(txt, null);
            }
        }
    }
}
