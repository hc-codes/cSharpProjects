﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Library.Models.Validators
{
    public class RequiredValidator
    {
        public int MinLength { get; set; } = 0;
        public int MaxLength { get; set; } = int.MaxValue;
        public string Validate(string arg)
        {
            if (string.IsNullOrEmpty(arg))
            {
                return " is required.";
            }
            else if(arg.Length<MinLength || arg.Length > MaxLength)
            {
                return $"Length must be between {MinLength} and {MaxLength}";
            }
            return null;
        }
    }
}
