﻿using Shop.Library.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Library.Repositories
{
    public class FileProductRepository : IProductRepository
    {
        private readonly string fileName = "ProductFile.data";
        private readonly char[] delimiter = { ',', ',' };
        private readonly string productFieldPattern = "{0},,{1},,{2},,{3},,{4}\n";
        public FileProductRepository()
        {
            this.Load();
        }
        private void Load()
        {
            using (FileStream file = new FileStream(fileName, FileMode.Open, FileAccess.Read))
            {
                StreamReader reader = new StreamReader(file);
                while (true)
                {
                    string pstr = reader.ReadLine();
                    if (pstr == null)
                    {
                        break;
                    }
                    Product p = Parse(pstr);
                    this.products.Add(p);
                }
            }
        }

        private Product Parse(string pstr)
        {
            Product p = new Product();
            string[] strArr = pstr.Split(delimiter, StringSplitOptions.RemoveEmptyEntries);
            p.Id = Convert.ToInt32(strArr[0]);
            p.Category = strArr[1];
            p.Name = strArr[2];
            p.Price = Convert.ToDouble(strArr[3]);
            p.Stock = Convert.ToInt32(strArr[4]);
            return p;
        }

        private void Save()
        {
            StringBuilder builder = new StringBuilder();
            foreach (var item in this.products)
            {
                string str = string.Format(productFieldPattern, item.Id, item.Category, item.Name, item.Price, item.Stock);
                builder.Append(str);
            }
            StreamWriter writer = null;
            try
            {
                FileStream file = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                writer = new StreamWriter(file);
                writer.Write(builder.ToString());
                writer.Flush();
            }
            //catch (Exception)
            //{
            //    throw;
            //}
            finally
            {
                if (writer != null)
                {
                    writer.Close();
                }
            }
        }
        private List<Product> products = new List<Product>();
        /// <summary>
        /// stores a product instance in the repository
        /// </summary>
        /// <param name="product">instance of product to be stored</param>
        public void Create(Product product)
        {
            this.products.Add(product);
            Save();
        }
        /// <summary>
        /// read the instance of the product with the given unique id
        /// </summary>
        /// <param name="id"> the id to look for</param>
        /// <returns> the instance of product with the id or null if not found</returns>
        public Product Read(int id)
        {
            foreach (var item in this.products)
            {
                if (item.Id == id)
                {
                    return item;
                }
            }
            return null;
        }
        /// <summary>
        /// returns a collection of products having the given category
        /// </summary>
        /// <param name="category"> the category to search for</param>
        /// <returns>a not null collection of products</returns>
        public List<Product> Read(string category)
        {
            List<Product> lst = new List<Product>();
            foreach (var item in products)
            {
                if (item.Category == category)
                {
                    lst.Add(item);
                }
            }
            return lst;
        }
        /// <summary>
        /// returns a collection of all products in the store
        /// </summary>
        /// <returns>a not null collection of all  products</returns>
        public IEnumerable<Product> Read()
        {
            return this.products;
        }

        public int GetNextId()
        {
            int nid = 0;
            foreach (var p in products)
            {
                if (p.Id > nid)
                {
                    nid = p.Id;
                }
            }
            return nid + 1;
        }

        public List<string> GetCategories()
        {
            List<string> cats = new List<string>();
            foreach (var p in this.products)
            {
                string cat = p.Category;
                if (!cats.Contains(cat))
                {
                    cats.Add(cat);
                }
            }

            return cats;
        }

        public List<Product> Search(string txt)
        {
            List<Product> lst = new List<Product>();
            foreach (var item in products)
            {
                if (item.Name.IndexOf(txt) >= 0)
                {
                    lst.Add(item);
                }
            }
            return lst;
        }
    }
}


