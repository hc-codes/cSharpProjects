﻿using Shop.Library.Models;
using Shop.Library.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinMyShop
{
    public partial class SalesForm : Form
    {
        private Cart shopCart;
        private IProductRepository productRepository;
        public SalesForm(IProductRepository productRepository)
        {
            InitializeComponent();
            this.productRepository = productRepository;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string txt = ((TextBox)sender).Text;
            if (txt.Length < 2)
            {
                return;
            }
            List<Product> products = this.productRepository.Search(txt);
            DisplaySearchResults(products);
        }

        private void DisplaySearchResults(List<Product> products)
        {
            lbResults.Items.Clear();
            foreach (var item in products)
            {
                lbResults.Items.Add(item);               
            }            
        }

        private void lbResults_SelectedIndexChanged(object sender, EventArgs e)
        {
            Product p = lbResults.SelectedItem as Product;
            if(p == null)
            {
                return;
            }
            if(this.shopCart == null)
            {
                this.shopCart = new Cart();
            }
            this.shopCart.Add(p);
            double total = this.shopCart.ComputeTotal();
            MessageBox.Show(total.ToString());
        }
    }
}
